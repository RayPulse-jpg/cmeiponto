// ============================================================
// CONFIGURAÇÃO DO FIREBASE
// ⚠️  Este arquivo NÃO deve ser commitado no git (.gitignore)
// ⚠️  Copie este arquivo de firebase-config.example.js
// ============================================================

const firebaseConfig = {
    apiKey: "AIzaSyCswoXWBPacdMKfHKUBili4SwHUj7566L8",
    authDomain: "folha-de-ponto-cmei.firebaseapp.com",
    databaseURL: "https://folha-de-ponto-cmei-default-rtdb.firebaseio.com",
    projectId: "folha-de-ponto-cmei",
    storageBucket: "folha-de-ponto-cmei.firebasestorage.app",
    messagingSenderId: "363750832405",
    appId: "1:363750832405:web:d0050043e6f2b4fde1111c",
    measurementId: "G-L5VZDVXHG6"
};
